const { app, BrowserWindow, globalShortcut } = require('electron');
const path = require('path');
const { desktopCapturer } = require('electron');

function createWindow() {
    const win = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
        },
    });

    win.loadFile('index.html');
}

app.whenReady().then(() => {
    createWindow();

    // Shortcut für 'Druck'-Taste, um einen Screenshot zu machen
    globalShortcut.register('PrintScreen', async () => {
        const sources = await desktopCapturer.getSources({ types: ['screen'] });
        for (const source of sources) {
            win.webContents.send('capture-screen', source);
            break;
        }
    });

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});
