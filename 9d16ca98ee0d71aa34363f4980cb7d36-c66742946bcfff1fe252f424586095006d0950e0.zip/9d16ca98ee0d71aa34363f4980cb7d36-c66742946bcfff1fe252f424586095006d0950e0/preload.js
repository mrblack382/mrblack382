const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    onCaptureScreen: (callback) => ipcRenderer.on('capture-screen', callback),
});
